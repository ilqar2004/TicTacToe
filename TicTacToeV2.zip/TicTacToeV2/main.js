let M = [];
let count = 1;
let X = "X";
let O = "O";

onload = () =>{
    createArray();
    createTable();
    players();
    Score();
};


const createArray = () =>{
    for(let i = 0; i<3;i++){
        M[i] = [];
        for(let j = 0; j<3;j++){
            M[i][j] = '';
        }
    }
};


const createTable = ()=>{
    let tbl= ``;
    for (let i = 0; i < 3; i++) {
        tbl += "<tr>";
        for (let j = 0; j < 3; j++) {
            tbl += `<td onclick="Click(${i},${j})">${M[i][j]}</td>`;
        }
        tbl += "</tr>";
    }
    document.getElementsByTagName("table")[0].innerHTML = tbl;

};

function Click(i,j){
   if(M[i][j] == ''){
        if(count%2 ==0){
            M[i][j] = O;
        }else{
            M[i][j] = X;
        }
        createTable();
        setTimeout(Check,400);
        count++;
   }
}

function Check(){
    if(M[0][0] == M[1][1] && M[1][1]==M[2][2] && M[0][0] != ""){
        alert(M[0][0]+" Win");
        location.reload();
    }
    else if(M[0][2] == M[1][1] && M[1][1]==M[2][0] && M[0][2] != ""){
        alert(M[0][2]+" Win");
        location.reload();
    }
    for(let i = 0; i<3;i++){
        if(M[i][0] == M[i][1] && M[i][1]==M[i][2] && M[i][0] != ""){
            alert(M[i][0]+" Win");
            location.reload();
        }
        if(M [0][i]== M[1][i] && M[1][i]==M[2][i] && M[0][i] != ""){
            alert(M[0][i]+" Win");
            location.reload();
        }
    }
}
function players(){
let name = prompt('X oyunçu adı:', );
// let scr = ``;
// scr += `<h1>:0</h1>`;

alert(`X ${name} oyuna qatıldı!`);

let name1 = prompt('O oyunçu adı:', );

alert(`O ${name1} oyuna qatıldı!`);

document.getElementById("oyuncu1").innerHTML = name;
document.getElementById("oyuncu2").innerHTML = name1;
document.getElementById("oyuncu1").innerHTML = scr;
}

// function Score(){
//     let scr = ``;
    
//     scr += `<h1>:0</h1>`;
//     document.getElementById("oyuncu1").innerHTML = scr;
// }